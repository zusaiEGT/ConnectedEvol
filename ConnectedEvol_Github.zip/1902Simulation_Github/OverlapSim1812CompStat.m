 %% Single-shot simulation of migration-assimilation dynamic
% Record the transition of individual preference & community

%NB. Fixed the alignments of S, G and BasePay to be consistent with the
%paper.

tic;
clear;
cd 
%close all

starttime=datestr(now,'yymmddHHMM');
ResultFolder=sprintf('./SimResults/Overlap%s',starttime)
mkdir(ResultFolder)
ResultXLS=[ResultFolder '/' sprintf('Overlap%s_result.xlsx',starttime)];
DiaryTXT=[ResultFolder '/' sprintf('Overlap%s_diary.txt',starttime)];

diary(DiaryTXT)

%%%%%%%%%%%%%%%%
%% Set up constants
%%%%%%%%%%%%%%%%
%The base game
ll=4     %Payoff from both using action L
rr=3     %Payoff from both using action R
lr=0     %Payoff from using different actions (without bilingual option)
e=0.75  %Bilateral cost (on each side) when matching with a bilingual
f=0  %Asymmetric cost to take a bilingual action
BasePay0=[   ll       ll-e      lr;   %For an Ao player
            ll-e-f    ll-e-f    rr-e-f;  %For an AB player
            lr      rr-e       rr]
%Strategy labels
S=[ 'LoAo' 'LoAB' 'LooB' ;%
    'LRAo' 'LRAB' 'LRoB' ;%
    'oRAo' 'oRAB' 'oRoB' ;]

%The connection matrix
G=[ 1 1 0; %Lo's impacts
    1 1 1; %LR's impacts
    0 1 1] %oR's impacts
    % (p,q)-th cell: p's impact on q's payoff
    

%The BRD
revAff=0  %the revision rate of  (only) affiliation "\cP"
revAct=0.05*(1-0.05) %the revision rate of (only) action "\cA" 
revBoth=0.05*0.05    %the revision rate of both action and affiliation "\cA\times\cP"

T=100   %the period of each iteration block



        
%%%%%%%%%%%%%%%%
%% Parameter values to be varied
%%%%%%%%%%%%%%%%

constPayGrid=[-0.05;-1;-5];

% Set the ranges of changing parameters

mGridsize=0.01;
[mLOGrid0,mORGrid0]=meshgrid(0+0.5*mGridsize:mGridsize:1-0.5*mGridsize);
mLOGrid=mLOGrid0(find(mLOGrid0+mORGrid0<1));
mORGrid=mORGrid0(find(mLOGrid0+mORGrid0<1));

for payIte=1:length(constPayGrid)
    constPay=constPayGrid(payIte);
    
BasePay=constPay*ones(3,3)+BasePay0;  %For an oB player

    %prepare an alignment to record the outcome of each simulation
    LimAct_H=zeros(size(mLOGrid));ite_H=zeros(size(mLOGrid));OptActEnd_H=zeros(length(mLOGrid),3);
    
    for mIte=1:length(mLOGrid) %start the loop: one loop m corresponds to one simulation of T-period dynamic
        mLO=mLOGrid(mIte);mOR=mORGrid(mIte);
        ite=1;
        
        %Initial state
        M_0=round(10000*[mLO  0   0;
            0   1-mLO-mOR    0;
            0   0  mOR]);
        
        TotalM=sum(M_0(:));
        
        
        %%%%%%%%%%%%%%%%%%%
        %% Individual agents' initial affiliation/action profiles
        %%%%%%%%%%%%%%%%%%%
        % In the following two lines,
        % we list all agents' affiliations and actions in vectors.
        
        Aff_0=[ 1*ones(M_0(1,1),1); 1*ones(M_0(1,2),1); 1*ones(M_0(1,3),1);%
            2*ones(M_0(2,1),1); 2*ones(M_0(2,2),1); 2*ones(M_0(2,3),1);%
            3*ones(M_0(3,1),1); 3*ones(M_0(3,2),1); 3*ones(M_0(3,3),1)];
        % The initial strategy=() of each agent
        % In Aff matrix, Aff(i)=1 means agent i's affiliation p(i)=Lo.
        % Aff(i)=2 for p(i)=LR, Aff(i)=3 for p(i)=oR.
        
        Act_0=[ 1*ones(M_0(1,1),1); 2*ones(M_0(1,2),1); 3*ones(M_0(1,3),1);%
            1*ones(M_0(2,1),1); 2*ones(M_0(2,2),1); 3*ones(M_0(2,3),1);%
            1*ones(M_0(3,1),1); 2*ones(M_0(3,2),1); 3*ones(M_0(3,3),1)];
        % The initial action of each agent
        % In Act matrix, Act(i)=1 means agent i's action a(i)=Ao.
        % Act(i)=2 for a(i)=AB, Act(i)=3 for a(i)=oB.
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %% Run the simulation
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        
        
        %% Set the initial values
        Aff_t=Aff_0;Act_t=Act_0;
        
        %% Make an iteration block
        while ite
            
            %% Run the dynamic for T periods
            for t=1:T+1 % each t corresponds to one period
                
                %Strategy distribution before the switches
                Str_t=Aff_t+10*Act_t; % Str(i)=(Act(i),Aff(i)) as a twi-digit number.
                X_t=[   sum(Str_t==11) sum(Str_t==12) sum(Str_t==13);
                    sum(Str_t==21) sum(Str_t==22) sum(Str_t==23);
                    sum(Str_t==31) sum(Str_t==32) sum(Str_t==33)]./TotalM;
                %Matrix X records the joint dist of (action, affiliation) pairs.
                %In 1609, it was a matrix of the _numbers_ of player of each pair.
                %Rows: 1st for Ao, 2nd for AB, 3rd for oB.
                %Columns: 1st for Lo, 2nd for LR, 3rd for oR.
                %X_H(:,:,t)=X_t; %Record into the history of X.
                
                %Payoff matrix of the structured game before the switches
                Pay_t= BasePay * X_t * G;
                %Payoff of each (action, affiliation) pair.
                %Pay_H(:,:,t)=Pay_t; %Record into the history of X.
                
                %Best responses
                [PayOptAct_t,OptAct_t]=max(Pay_t,[],1);
                [PayOptAff_t,OptAff_t]=max(Pay_t,[],2);
                [PayOptBoth_t,OptBoth_t]=max(Pay_t(:));[OptBothAct_t,OptBothAff_t]=ind2sub(size(Pay_t),OptBoth_t);
                %Revisions
                Rev_t=rand(TotalM,1);
                %Rev_t(i)=<revAff => agent i gets the rev opp of affiliation
                %revAff<Rev_t(i)=<revAff+revAct => agent i gets the rev opp of action
                %revAff<Rev_t(i)=<revAff+revAct => agent i gets the rev opp of action
                RevAct_t=(Rev_t<=revAct & Pay_t(sub2ind(size(Pay_t),Act_t,Aff_t))<PayOptAct_t(Aff_t)');
                Act_t=(ones(TotalM,1)-RevAct_t).*Act_t+RevAct_t.*OptAct_t(Aff_t)';
                
                RevAff_t=(revAct<Rev_t & Rev_t<=revAct+revAff & Pay_t(sub2ind(size(Pay_t),Act_t,Aff_t))<PayOptAff_t(Act_t));
                Aff_t=(ones(TotalM,1)-RevAff_t).*Aff_t+RevAff_t.*OptAff_t(Act_t);
                
                RevBoth_t=(revAct+revAff<Rev_t & Rev_t<=revAct+revAff+revBoth & Pay_t(sub2ind(size(Pay_t),Act_t,Aff_t))<PayOptBoth_t);
                Act_t=(ones(TotalM,1)-RevBoth_t).*Act_t+RevBoth_t.*OptBothAct_t;
                Aff_t=(ones(TotalM,1)-RevBoth_t).*Aff_t+RevBoth_t.*OptBothAff_t;
                
            end %Ends the T-iteration of the dynamic
            
            if all(OptAct_t==1) %BR action is Ao in all populations
                LimAct=1; break %In the limit state, everyone should be taking Ao.
            elseif all(OptAct_t==3) %BR action is oB in all populations
                LimAct=2; break %In the limit state, everyone should be taking oB.
            elseif (ite>100) %The BR action do not converge yet after 100*T iterations.
                LimAct=0;break; %Quit simulations under this parameter value.
            end
            ite=ite+1;
            
        end
        
        LimAct_H(mIte)=LimAct;ite_H(mIte)=ite;OptActEnd_H(mIte,:)=OptAct_t;
        
    end
    
    
    %clear Str_t X_t Pay_t PayOptAct_t OptAct_t PayOptAff_t OptAff_t Rev_t RevAct_t RevAff_t RevBoth_t RevBothAff_t RevBothAct_t;
    
    %% Record in Excel file
    SheetTitle=sprintf('Result%d',payIte);
    xlswrite(ResultXLS,{'constPay','mLO','mOR','LimAct','ite','OptActEnd_Lo','OptActEnd_LR','OptActEnd_oR'},SheetTitle);
    xlswrite(ResultXLS,[constPay*ones(size(mLOGrid)),mLOGrid,mORGrid,LimAct_H,ite_H,OptActEnd_H],SheetTitle,'A2');
    
    figure;
    plot(mLOGrid(LimAct_H==1),mORGrid(LimAct_H==1),'ro'); hold on;
    plot(mLOGrid(LimAct_H==2),mORGrid(LimAct_H==2),'bo');
    plot(mLOGrid(LimAct_H==0),mORGrid(LimAct_H==0),'k.');
    xlim([0 1]);ylim([0 1]);
    
    
    %If "the server returns an exception error", try the followings
    % - uncheck all the COM add-on in Excel (Option/Add-on/COM from pull-down menu near bottom)
    % - end all the Excel processes from Window's Task Manager before running this
    % m-file.
end

diary(DiaryTXT)
elapsedTime=toc;
disp(sprintf('Finished in %5.2f seconds.',elapsedTime))
diary off
beep