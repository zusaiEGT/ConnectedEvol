 %% Single-shot simulation of migration-assimilation dynamic
% Record the transition of individual preference & community

tic;
clear;
cd 
close all

starttime=datestr(now,'yymmddHHMM');
ResultFolder=sprintf('./SimResults/Overlap%s',starttime)
mkdir(ResultFolder)
ResultXLS=[ResultFolder '/' sprintf('Overlap%s_result.xlsx',starttime)];
DiaryTXT=[ResultFolder '/' sprintf('Overlap%s_diary.txt',starttime)];

diary(DiaryTXT)

%%%%%%%%%%%%%%%%
%% parameters
%%%%%%%%%%%%%%%%
%The base game
ll=4     %Payoff from both using action L
rr=3     %Payoff from both using action R
lr=0     %Payoff from using different actions (without bilingual option)
e=0.75  %Bilateral cost (on each side) when matching with a bilingual
f=1.00  %Asymmetric cost to take a bilingual action

%Strategy labels
S=[ 'LoAo' 'LooB' 'LoAB';%
    'oRAo' 'oRoB' 'oRAB';%
    'LRAo' 'LRoB' 'LRAB']

%The connection matrix
G=[ 1 0 1; %Lo's impacts
    0 1 1; %oR's impacts
    1 1 1] %LR's impacts
    % (p,q)-th cell: p's impact on q's payoff
    
%Initial state
M_0=[20000  0   0;
    0   20000    0;
    0   0   10000]

TotalM=sum(M_0(:));

%The BRD
revAff=0.05*(1-0.05)/2  %the revision rate of (only) action "\cA" 
revAct=0.05*(1-0.05)/2 %the revision rate of (only) affiliation "\cP"
revBoth=0.05*0.05    %the revision rate of both action and affiliation "\cA\times\cP"

% The time horizon
T=400   %the period of each simulation
% Grids of periods on the graphs 
% TimeTicks=[25,50,75,100];
%TimeTicks=[round(T*0.25) round(T*0.5) round(T*0.75) T];
TimeTicks=round(linspace(0,T,5));

%%%%%%%%%%%%%%%%
%% Base Payoff matrix
%%%%%%%%%%%%%%%%
BasePay=[   ll      lr       ll-e;   %For an Ao player
            lr       rr      rr-e;   %For an oB player
            ll-e-f    rr-e-f    ll-e-f]  %For an AB player

%%%%%%%%%%%%%%%%%%%
%% Individual agents' initial affiliation/action profiles
%%%%%%%%%%%%%%%%%%%
% In the following two lines, 
% we list all agents' affiliations and actions in vectors.

Aff_0=[ 1*ones(M_0(1,1),1); 1*ones(M_0(1,2),1); 1*ones(M_0(1,3),1);%
        2*ones(M_0(2,1),1); 2*ones(M_0(2,2),1); 2*ones(M_0(2,3),1);%
        3*ones(M_0(3,1),1); 3*ones(M_0(3,2),1); 3*ones(M_0(3,3),1)];
    % The initial strategy=() of each agent
    % In Aff matrix, Aff(i)=1 means agent i's affiliation p(i)=Lo.
    % Aff(i)=2 for p(i)=oR, Aff(i)=3 for p(i)=LR.

Act_0=[ 1*ones(M_0(1,1),1); 2*ones(M_0(1,2),1); 3*ones(M_0(1,3),1);%
        1*ones(M_0(2,1),1); 2*ones(M_0(2,2),1); 3*ones(M_0(2,3),1);%
        1*ones(M_0(3,1),1); 2*ones(M_0(3,2),1); 3*ones(M_0(3,3),1)];
    % The initial action of each agent
    % In Act matrix, Act(i)=1 means agent i's action a(i)=Ao.
    % Act(i)=2 for a(i)=oB, Act(i)=3 for a(i)=AB.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Run the simulation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Prepare recording variables to keep the history of each variable
X_H=zeros(3,3,T); Pay_H=zeros(3,3,T);

%% Set the initial values
Aff_t=Aff_0;Act_t=Act_0;

%% Run the dynamic
for t=1:T+1 % each t corresponds to one period

    %Strategy distribution before the switches
    Str_t=Aff_t+10*Act_t; % Str(i)=(Act(i),Aff(i)) as a twi-digit number.
    X_t=[   sum(Str_t==11) sum(Str_t==12) sum(Str_t==13);
            sum(Str_t==21) sum(Str_t==22) sum(Str_t==23);
            sum(Str_t==31) sum(Str_t==32) sum(Str_t==33)]./TotalM;
        %Matrix X records the joint dist of (action, affiliation) pairs.
        %In 1609, it was a matrix of the _numbers_ of player of each pair.
        %Rows: 1st for Ao, 2nd for oB, 3rd for AB.
        %Columns: 1st for Lo, 2nd for oR, 3rd for LR.
    X_H(:,:,t)=X_t; %Record into the history of X.
    
    %Payoff matrix of the structured game before the switches
    Pay_t= BasePay * X_t * G;
        %Payoff of each (action, affiliation) pair.
    Pay_H(:,:,t)=Pay_t; %Record into the history of X.

    %Best responses
    [PayOptAct_t,OptAct_t]=max(Pay_t,[],1);
    [PayOptAff_t,OptAff_t]=max(Pay_t,[],2);    
    [PayOptBoth_t,OptBoth_t]=max(Pay_t(:));[OptBothAct_t,OptBothAff_t]=ind2sub(size(Pay_t),OptBoth_t);
    %Revisions
    Rev_t=rand(TotalM,1); 
        %Rev_t(i)=<revAff => agent i gets the rev opp of affiliation
        %revAff<Rev_t(i)=<revAff+revAct => agent i gets the rev opp of action
        %revAff<Rev_t(i)=<revAff+revAct => agent i gets the rev opp of action
    RevAct_t=(Rev_t<=revAct & Pay_t(sub2ind(size(Pay_t),Act_t,Aff_t))<PayOptAct_t(Aff_t)');
    Act_t=(ones(TotalM,1)-RevAct_t).*Act_t+RevAct_t.*OptAct_t(Aff_t)';
    
    RevAff_t=(revAct<Rev_t & Rev_t<=revAct+revAff & Pay_t(sub2ind(size(Pay_t),Act_t,Aff_t))<PayOptAff_t(Act_t));
    Aff_t=(ones(TotalM,1)-RevAff_t).*Aff_t+RevAff_t.*OptAff_t(Act_t);
    
    RevBoth_t=(revAct+revAff<Rev_t & Rev_t<=revAct+revAff+revBoth & Pay_t(sub2ind(size(Pay_t),Act_t,Aff_t))<PayOptBoth_t);
    Act_t=(ones(TotalM,1)-RevBoth_t).*Act_t+RevBoth_t.*OptBothAct_t;
    Aff_t=(ones(TotalM,1)-RevBoth_t).*Aff_t+RevBoth_t.*OptBothAff_t;

 end %Ends the dynamic

%clear Str_t X_t Pay_t PayOptAct_t OptAct_t PayOptAff_t OptAff_t Rev_t RevAct_t RevAff_t RevBoth_t RevBothAff_t RevBothAct_t; 

%% Plot the results
PopShareTicks=linspace(0,1,6);
PayoffLims=[min(BasePay(:)) max(BasePay(:))];
PayoffTicks=round(linspace(min(BasePay(:)),max(BasePay(:)),5),2);

figure; hold on
Currfig=bar(squeeze(X_H(:,1,:))',1,'stacked','Linestyle','none');
set(Currfig(1),'facecolor','r');set(Currfig(2),'facecolor','b');set(Currfig(3),'facecolor','m');
ax=gca;ax.FontSize=24;
xlabel('period','FontName','Ariel','FontSize',24);xlim([1 T]);xticks(TimeTicks);
ylabel('population share','FontName','Ariel','FontSize',24);ylim([0 1]);yticks(PopShareTicks);
FigJpegPrintNoLeg([ResultFolder '/' sprintf('Overlap%s_X_Lo',starttime)],'Act dist in population Lo')

figure; hold on
Currfig=bar(squeeze(X_H(:,2,:))',1,'stacked','Linestyle','none');
set(Currfig(1),'facecolor','r');set(Currfig(2),'facecolor','b');set(Currfig(3),'facecolor','m');
ax=gca;ax.FontSize=24;
xlabel('period','FontName','Ariel','FontSize',24);xlim([1 T]);xticks(TimeTicks);
ylabel('population share','FontName','Ariel','FontSize',24);ylim([0 1]);yticks(PopShareTicks);
FigJpegPrintNoLeg([ResultFolder '/' sprintf('Overlap%s_X_oR',starttime)],'Act dist in population oR')

figure; hold on
Currfig=bar(squeeze(X_H(:,3,:))',1,'stacked','Linestyle','none');
set(Currfig(1),'facecolor','r');set(Currfig(2),'facecolor','b');set(Currfig(3),'facecolor','m');
ax=gca;ax.FontSize=24;
xlabel('period','FontName','Ariel','FontSize',24);xlim([1 T]);xticks(TimeTicks);
ylabel('population share','FontName','Ariel','FontSize',24);ylim([0 1]);yticks(PopShareTicks);
FigJpegPrintNoLeg([ResultFolder '/' sprintf('Overlap%s_X_LR',starttime)],'Act dist in population LR')

figure; hold on
Currfig=plot(squeeze(Pay_H(:,1,:))','Linewidth',2.5);
set(Currfig(1),'Color','r');set(Currfig(2),'Color','b');set(Currfig(3),'Color','m');
ax=gca;ax.FontSize=24;
xlabel('period','FontName','Ariel','FontSize',24);xlim([1 T]);xticks(TimeTicks);
ylabel('payoff','FontName','Ariel','FontSize',24);ylim(PayoffLims);yticks(PayoffTicks);
FigJpegPrintNoLeg([ResultFolder '/' sprintf('Overlap%s_P_Lo',starttime)],'Payoffs in population Lo')

figure; hold on
Currfig=plot(squeeze(Pay_H(:,2,:))','Linewidth',2.5);
set(Currfig(1),'Color','r');set(Currfig(2),'Color','b');set(Currfig(3),'Color','m');
ax=gca;ax.FontSize=24;
xlabel('period','FontName','Ariel','FontSize',24);xlim([1 T]);xticks(TimeTicks);
ylabel('payoff','FontName','Ariel','FontSize',24);ylim(PayoffLims);yticks(PayoffTicks);
FigJpegPrintNoLeg([ResultFolder '/' sprintf('Overlap%s_P_oR',starttime)],'Payoffs in population oR')

figure; hold on
Currfig=plot(squeeze(Pay_H(:,3,:))','Linewidth',2.5);
set(Currfig(1),'Color','r');set(Currfig(2),'Color','b');set(Currfig(3),'Color','m');
ax=gca;ax.FontSize=24;
xlabel('period','FontName','Ariel','FontSize',24);xlim([1 T]);xticks(TimeTicks);
ylabel('payoff','FontName','Ariel','FontSize',24);ylim(PayoffLims);yticks(PayoffTicks);
FigJpegPrintNoLeg([ResultFolder '/' sprintf('Overlap%s_P_LR',starttime)],'Payoffs in population LR')

xlswrite(ResultXLS,{'period','xLoAo','xLooB','xLoAB','xoRAo','xoRoB','xRoAB','xLRAo','xLRoB','xLRAB'},'Numbers');
xlswrite(ResultXLS,[(1:T+1)',squeeze(X_H(:,1,:))',squeeze(X_H(:,2,:))',squeeze(X_H(:,3,:))'],'Numbers','A2');

xlswrite(ResultXLS,{'period','payLoAo','payLooB','payLoAB','payoRAo','payoRoB','payRoAB','payLRAo','payLRoB','payLRAB'},'Payoffs');
xlswrite(ResultXLS,[(1:T+1)',squeeze(Pay_H(:,1,:))',squeeze(Pay_H(:,2,:))',squeeze(Pay_H(:,3,:))'],'Payoffs','A2');
    %If "the server returns an exception error", try the followings
    % - uncheck all the COM add-on in Excel (Option/Add-on/COM from pull-down menu near bottom)
    % - end all the Excel processes from Window's Task Manager before running this
    % m-file.

diary(DiaryTXT)
elapsedTime=toc;
disp(sprintf('Finished in %5.2f seconds.',elapsedTime))
diary off

%% History
% 1st version Sept 2016 by Dai during visit to Eugene