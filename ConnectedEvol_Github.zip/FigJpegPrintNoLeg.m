function FigJpegSetNoLeg(FileName,FigTitle)
% FigJpegSet.m
width  = 1024;height = 768;
set(gcf,'PaperPositionMode','auto')
pos=get(gcf,'Position');pos(3)=width-1; pos(4)=height;set(gcf,'Position',pos);
print([FileName '.jpg'],'-djpeg','-r0') %Print a jpge file without the title line (to be included in another document).
title(FigTitle, 'FontName','Ariel','FontSize',18);
saveas(gcf,[FileName '.fig']);
